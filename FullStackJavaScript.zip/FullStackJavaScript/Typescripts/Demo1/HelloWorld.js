var message="Hello To All Welcome to TypeScript"

message=100;
console.log(message)
