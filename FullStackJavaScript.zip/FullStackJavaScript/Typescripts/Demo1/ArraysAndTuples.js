var numList = [10, 20, 30, 40, 50];
for (var index = 0; index < numList.length; index++) {
    console.log(numList[index]);
}
numList.forEach(function (element) { return console.log(element); });
/*for (const num of numList) {
    console.log(num)
}*/
/*for (const idx in numList) {
    console.log(numList[idx])
}*/
//Tuples
/*var varArgsArray=[10,20,30,"Satish Mahajan" , 10.34]

varArgsArray.forEach(element => {
    console.log(element)
})*/ 
