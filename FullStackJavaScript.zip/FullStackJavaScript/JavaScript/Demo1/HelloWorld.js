function callForWork(){
	console.log("hello World From JavaScript")
}
callForWork();

/* var num = 10;
console.log(num);
num = 'Hello Wolrd';
console.log(num) */